# आयशा कम्युनिटी – APK बनाने के स्टेप्स
1. console.firebase.google.com → नया प्रोजेक्ट → Add app → Web (</>) → config कॉपी करें → `www/firebase-config.js` में पेस्ट करें।
2. Firebase → Build → Authentication → Sign-in method → **Email/Password** ऑन करें।
3. Firebase → Build → Firestore Database → Create (Production mode) → Rules टैब में `firestore.rules` की पूरी फ़ाइल पेस्ट करके Publish करें।
4. GitHub पर नई repo बनाएँ, इस ZIP की सारी फ़ाइलें (`.github` फ़ोल्डर समेत) अपलोड करें।
5. repo → Actions → "Build APK" (अपने आप चलेगा) → ख़त्म होने पर नीचे Artifacts से `ayesha-community-apk` डाउनलोड करें → ज़िप खोलकर `app-debug.apk` इंस्टॉल करें।
