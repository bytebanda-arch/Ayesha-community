import {firebaseConfig} from './firebase-config.js';
import {DUAS} from './duas.js';
import {initializeApp} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import {getAuth,onAuthStateChanged,createUserWithEmailAndPassword,signInWithEmailAndPassword,signOut,sendPasswordResetEmail} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import {getFirestore,doc,getDoc,setDoc,addDoc,collection,query,where,orderBy,limitToLast,onSnapshot,updateDoc,arrayUnion,arrayRemove,serverTimestamp,writeBatch,deleteDoc,getDocs} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LS={get:(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},set:(k,v)=>localStorage.setItem(k,JSON.stringify(v))};
const fb=initializeApp(firebaseConfig),auth=getAuth(fb),db=getFirestore(fb);
let me=null,stack=[],unsubs=[],cleanups=[],chats=[],invites=[],signingUp=false,inboxOpen=false,aud=null;
const views={},acts={};
const TITLES={home:'आयशा कम्युनिटी',quran:'क़ुरान शरीफ़',dua:'दुआएँ',tasbih:'तस्बीह',community:'कम्युनिटी',qibla:'क़िब्ला',profile:'प्रोफ़ाइल'};
const cur=()=>stack.at(-1)?.name;

function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),2600)}
const modal=h=>{const e=$('#modal');e.innerHTML=`<div class="sheet">${h}</div>`;e.hidden=false};
const closeModal=()=>{$('#modal').hidden=true;inboxOpen=false};
document.addEventListener('click',e=>{if(e.target.id==='modal')return closeModal();const b=e.target.closest('[data-a]');if(b&&acts[b.dataset.a])acts[b.dataset.a](b.dataset,b)});

/* ---------- navigation ---------- */
function render(){cleanups.forEach(f=>{try{f()}catch{}});cleanups=[];const v=stack.at(-1);document.body.dataset.v=v.name;
  $('#title').textContent=TITLES[v.name]||'आयशा कम्युनिटी';$('#back').hidden=stack.length<2;
  document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.t===stack[0].name));
  $('#main').scrollTop=0;views[v.name](v.p)}
const tab=n=>{stack=[{name:n,p:{}}];render()};
const go=(name,p={})=>{stack.push({name,p});render()};
const back=()=>{if(!$('#modal').hidden)return closeModal();if(stack.length>1){stack.pop();render()}else if(stack[0].name!=='home')tab('home');else window.Capacitor?.Plugins?.App?.exitApp()};
acts.back=back;acts.close=closeModal;
acts.nav=d=>['qibla','profile'].includes(d.n)?go(d.n):tab(d.n);
window.Capacitor?.Plugins?.App?.addListener('backButton',back);

/* ---------- auth ---------- */
const errMsg=e=>({'auth/invalid-credential':'ईमेल या पासवर्ड ग़लत है','auth/email-already-in-use':'यह ईमेल पहले से रजिस्टर है','auth/weak-password':'पासवर्ड कम से कम 6 अक्षर का रखें','auth/invalid-email':'ईमेल सही नहीं है','auth/network-request-failed':'इंटरनेट चेक करें'}[e.code]||e.message||'कुछ गड़बड़ हो गई');
function authView(mode='login'){const a=$('#auth');a.hidden=false;$('#shell').hidden=true;
  a.innerHTML=`<div class="authbox"><div class="logo">🕌</div><h2>आयशा कम्युनिटी</h2><p class="mu">अस्सलामु अलैकुम 🌙</p>
  ${mode==='signup'?`<input id="a_name" placeholder="पूरा नाम (जैसे: आयशा ख़ान)"><input id="a_nick" placeholder="निकनेम (जैसे: ayesha_k)" autocapitalize="none" autocomplete="off">`:''}
  <input id="a_mail" type="email" placeholder="ईमेल" autocapitalize="none"><input id="a_pass" type="password" placeholder="पासवर्ड (कम से कम 6 अक्षर)">
  <button class="btn" data-a="doauth" data-m="${mode}">${mode==='signup'?'अकाउंट बनाएँ':'लॉगिन'}</button>
  ${mode==='login'?'<button class="lnk" data-a="forgot">पासवर्ड भूल गए?</button>':''}
  <button class="lnk" data-a="swauth" data-m="${mode==='login'?'signup':'login'}">${mode==='login'?'नया अकाउंट बनाएँ':'पहले से अकाउंट है? लॉगिन करें'}</button></div>`}
acts.swauth=d=>authView(d.m);
acts.forgot=async()=>{const m=$('#a_mail').value.trim();if(!m)return toast('पहले ईमेल लिखें');try{await sendPasswordResetEmail(auth,m);toast('रीसेट लिंक ईमेल पर भेज दिया')}catch(e){toast(errMsg(e))}};
acts.doauth=async(d,b)=>{const mail=$('#a_mail').value.trim(),pass=$('#a_pass').value;b.disabled=true;
  try{if(d.m==='signup'){
      const name=$('#a_name').value.trim(),nick=$('#a_nick').value.trim().toLowerCase().replace(/^@/,'');
      if(!name)throw{message:'नाम लिखें'};
      if(!/^[a-z0-9_.]{3,20}$/.test(nick))throw{message:'निकनेम 3-20 अक्षर का हो: a-z, 0-9, _ या .'};
      if((await getDoc(doc(db,'usernames',nick))).exists())throw{message:'यह निकनेम पहले से लिया जा चुका है'};
      signingUp=true;const cr=await createUserWithEmailAndPassword(auth,mail,pass);
      try{const bt=writeBatch(db);bt.set(doc(db,'usernames',nick),{uid:cr.user.uid});bt.set(doc(db,'users',cr.user.uid),{name,nick,email:mail,createdAt:serverTimestamp()});await bt.commit()}
      catch(e){await cr.user.delete();signingUp=false;throw{message:'निकनेम उपलब्ध नहीं है, दूसरा चुनें'}}
      signingUp=false;await boot(cr.user)
    }else await signInWithEmailAndPassword(auth,mail,pass)
  }catch(e){signingUp=false;toast(errMsg(e))}finally{b.disabled=false}};
async function boot(u){const s=await getDoc(doc(db,'users',u.uid));if(!s.exists()){await signOut(auth);return authView('signup')}
  me={uid:u.uid,...s.data()};$('#auth').hidden=true;$('#shell').hidden=false;startListeners();tab('home')}
onAuthStateChanged(auth,u=>{if(signingUp)return;if(!u){me=null;unsubs.forEach(f=>f());unsubs=[];chats=[];invites=[];if($('#auth').hidden)authView('login')}else if(!me)boot(u)});
if(firebaseConfig.apiKey==='PASTE_HERE'){document.body.innerHTML='<p style="padding:30px">⚠️ www/firebase-config.js में Firebase की config पेस्ट करें।</p>'}

/* ---------- realtime listeners ---------- */
function startListeners(){
  unsubs.push(onSnapshot(query(collection(db,'chats'),where('members','array-contains',me.uid)),s=>{
    chats=s.docs.map(d=>({id:d.id,...d.data({serverTimestamps:'estimate'})})).sort((a,b)=>(b.lastAt?.toMillis?.()||0)-(a.lastAt?.toMillis?.()||0));
    if(cur()==='community')render()}));
  unsubs.push(onSnapshot(query(collection(db,'invites'),where('to','==',me.uid)),s=>{
    invites=s.docs.map(d=>({id:d.id,...d.data()}));const b=$('#badge');b.textContent=invites.length;b.hidden=!invites.length;if(inboxOpen)showInbox()}))}

/* ---------- invites / community ---------- */
async function lookup(nick){nick=nick.trim().toLowerCase().replace(/^@/,'');if(!nick)return null;
  const s=await getDoc(doc(db,'usernames',nick));if(!s.exists())return null;const u=await getDoc(doc(db,'users',s.data().uid));return u.exists()?{uid:u.id,...u.data()}:null}
async function sendInvite(chat,nick){try{const u=await lookup(nick);if(!u)return toast('ऐसा यूज़र नहीं मिला');
  if(u.uid===me.uid)return toast('यह आप ही हैं 🙂');if(chat.members.includes(u.uid))return toast('पहले से मेंबर है');
  await setDoc(doc(db,'invites',chat.id+'_'+u.uid),{to:u.uid,from:me.uid,fromNick:me.nick,chatId:chat.id,chatName:chat.name,at:serverTimestamp()});
  toast(`@${u.nick} को इनवाइट भेज दिया ✅`)}catch(e){toast(errMsg(e))}}
function showInbox(){inboxOpen=true;modal(`<h3>✉ इनवाइट</h3>`+(invites.length?invites.map(i=>`<div class="item"><span class="av">👥</span><div class="fl"><b>${esc(i.chatName)}</b><small class="mu">@${esc(i.fromNick)} ने बुलाया</small></div><button class="mini" data-a="acc" data-id="${i.id}" data-c="${i.chatId}">मंज़ूर</button><button class="mini" data-a="dec" data-id="${i.id}">✕</button></div>`).join(''):'<p class="mu center">कोई नया इनवाइट नहीं</p>')+'<button class="lnk" data-a="close">बंद करें</button>')}
acts.inbox=showInbox;
acts.acc=async d=>{try{await updateDoc(doc(db,'chats',d.c),{members:arrayUnion(me.uid)});await deleteDoc(doc(db,'invites',d.id));toast('ग्रुप जॉइन हो गया ✅')}catch(e){toast(errMsg(e))}};
acts.dec=async d=>{await deleteDoc(doc(db,'invites',d.id))};

const chatTitle=c=>c.type==='dm'?(c.names?.[c.members.find(x=>x!==me.uid)]||'यूज़र'):c.name;
views.community=()=>{$('#main').innerHTML=`<div class="row2"><button class="btn" data-a="newgrp">👥 नया ग्रुप</button><button class="btn alt" data-a="newdm">💬 नया मैसेज</button></div>`+
  (chats.length?chats.map(c=>`<div class="item" data-a="openchat" data-id="${c.id}"><span class="av">${c.type==='dm'?'👤':'👥'}</span><div class="fl"><b>${esc(chatTitle(c))}</b><small class="mu">${esc(c.lastMsg||'अभी कोई मैसेज नहीं')}</small></div></div>`).join(''):'<p class="mu center">अभी कोई चैट नहीं।<br>ग्रुप बनाएँ या @निकनेम से किसी को मैसेज करें।</p>')};
acts.openchat=d=>{const c=chats.find(x=>x.id===d.id);if(c)go('chat',{id:c.id,title:chatTitle(c),dm:c.type==='dm'})};
acts.newgrp=()=>modal(`<h3>👥 नया ग्रुप</h3><input id="gn" placeholder="ग्रुप का नाम"><input id="gm" placeholder="@निकनेम से मेंबर बुलाएँ (ज़रूरी नहीं)" autocapitalize="none"><button class="btn" data-a="mkgrp">ग्रुप बनाएँ</button><button class="lnk" data-a="close">बंद करें</button>`);
acts.mkgrp=async()=>{const name=$('#gn').value.trim(),nick=$('#gm').value;if(!name)return toast('ग्रुप का नाम लिखें');
  try{const r=await addDoc(collection(db,'chats'),{type:'group',name,admin:me.uid,members:[me.uid],createdAt:serverTimestamp(),lastAt:serverTimestamp(),lastMsg:''});
    if(nick.trim())await sendInvite({id:r.id,name,members:[me.uid]},nick);closeModal();go('chat',{id:r.id,title:name,dm:false})}catch(e){toast(errMsg(e))}};
acts.newdm=async()=>{modal(`<h3>💬 नया मैसेज</h3><div class="row"><input id="dn" placeholder="@निकनेम" autocapitalize="none"><button class="btn" data-a="stdm">खोलें</button></div><p class="mu">सेव किए कॉन्टैक्ट</p><div id="cl">…</div><button class="lnk" data-a="close">बंद करें</button>`);
  try{const s=await getDocs(collection(db,'users',me.uid,'contacts'));$('#cl').innerHTML=s.docs.map(d=>`<div class="item" data-a="dmc" data-u="${d.id}"><span class="av">👤</span><div class="fl"><b>${esc(d.data().name)}</b><small class="mu">@${esc(d.data().nick)}</small></div></div>`).join('')||'<p class="mu">अभी कोई कॉन्टैक्ट नहीं</p>'}catch{}};
acts.stdm=async()=>{try{const u=await lookup($('#dn').value);if(!u)return toast('ऐसा यूज़र नहीं मिला');if(u.uid===me.uid)return toast('यह आप ही हैं 🙂');openDM(u)}catch(e){toast(errMsg(e))}};
acts.dmc=async d=>{const s=await getDoc(doc(db,'users',d.u));if(s.exists())openDM({uid:s.id,...s.data()})};
async function openDM(u){const id=[me.uid,u.uid].sort().join('_');
  try{await setDoc(doc(db,'chats',id),{type:'dm',members:[me.uid,u.uid],names:{[me.uid]:me.name,[u.uid]:u.name}},{merge:true});
    await setDoc(doc(db,'users',me.uid,'contacts',u.uid),{name:u.name,nick:u.nick});closeModal();go('chat',{id,title:u.name,dm:true})}catch(e){toast(errMsg(e))}}

/* ---------- chat ---------- */
views.chat=({id,title,dm})=>{$('#title').innerHTML=dm?esc(title):`<span data-a="ginfo">${esc(title)} <small>ⓘ</small></span>`;
  $('#main').innerHTML=`<div class="chat"><div id="msgs"></div><div class="composer"><input id="mi" placeholder="मैसेज लिखें…" autocomplete="off"><button class="send" data-a="send">➤</button></div></div>`;
  $('#mi').onkeydown=e=>{if(e.key==='Enter')acts.send()};let first=true;
  cleanups.push(onSnapshot(query(collection(db,'chats',id,'messages'),orderBy('at'),limitToLast(200)),s=>{const box=$('#msgs');if(!box)return;
    const near=box.scrollHeight-box.scrollTop-box.clientHeight<120;
    box.innerHTML=s.docs.map(d=>{const x=d.data({serverTimestamps:'estimate'}),mine=x.from===me.uid,tm=x.at?.toDate?x.at.toDate().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}):'';
      return `<div class="b ${mine?'me':'ot'}">${!mine&&!dm?`<small class="who">@${esc(x.fromNick)}</small>`:''}<div>${esc(x.text)}</div><small class="tm">${tm}</small></div>`}).join('')||'<p class="mu center">पहला मैसेज भेजें — "हाय" 👋</p>';
    if(near||first)box.scrollTop=box.scrollHeight;first=false},e=>toast(errMsg(e))))};
acts.send=async()=>{const i=$('#mi'),t=i.value.trim();if(!t)return;i.value='';i.focus();const {id}=stack.at(-1).p;
  try{await addDoc(collection(db,'chats',id,'messages'),{text:t,from:me.uid,fromNick:me.nick,fromName:me.name,at:serverTimestamp()});
    await updateDoc(doc(db,'chats',id),{lastMsg:t.slice(0,60),lastAt:serverTimestamp()})}catch(e){toast('मैसेज नहीं भेज पाए')}};
acts.ginfo=async()=>{const {id}=stack.at(-1).p,c=chats.find(x=>x.id===id);if(!c)return;
  modal(`<h3>${esc(c.name)}</h3><p class="mu">मेंबर्स (${c.members.length})</p><div id="mem">…</div>${c.admin===me.uid?`<div class="row"><input id="addn" placeholder="@निकनेम जोड़ें" autocapitalize="none"><button class="btn" data-a="addmem">भेजें</button></div>`:''}<button class="btn danger" data-a="leave">ग्रुप छोड़ें</button><button class="lnk" data-a="close">बंद करें</button>`);
  const us=await Promise.all(c.members.map(u=>getDoc(doc(db,'users',u))));
  $('#mem').innerHTML=us.map(s=>s.exists()?`<div class="item"><div class="fl"><b>${esc(s.data().name)}</b><small class="mu">@${esc(s.data().nick)}${s.id===c.admin?' • एडमिन':''}</small></div></div>`:'').join('')};
acts.addmem=async()=>{const c=chats.find(x=>x.id===stack.at(-1).p.id);await sendInvite(c,$('#addn').value);$('#addn').value=''};
acts.leave=async()=>{const {id}=stack.at(-1).p;try{await updateDoc(doc(db,'chats',id),{members:arrayRemove(me.uid)});closeModal();tab('community')}catch(e){toast(errMsg(e))}};

/* ---------- home / prayer times ---------- */
async function getPos(){const P=window.Capacitor?.Plugins?.Geolocation;
  if(P){try{await P.requestPermissions()}catch{}const r=await P.getCurrentPosition({timeout:15000});return{lat:r.coords.latitude,lon:r.coords.longitude}}
  return new Promise((ok,no)=>navigator.geolocation.getCurrentPosition(p=>ok({lat:p.coords.latitude,lon:p.coords.longitude}),no,{timeout:15000}))}
acts.loadpt=async()=>{try{const {lat,lon}=await getPos();const j=await(await fetch(`https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lon}&method=1&school=1`)).json();LS.set('pt',{t:j.data.timings,h:j.data.date.hijri})}catch{toast('लोकेशन की इजाज़त / इंटरनेट चेक करें')}renderPrayer()};
function renderPrayer(){const el=$('#prayer');if(!el)return;const p=LS.get('pt');
  if(!p){el.innerHTML=`<b>🕌 नमाज़ के औक़ात</b><p class="mu">लोकेशन से अपने शहर के नमाज़ टाइम लाएँ</p><button class="btn" data-a="loadpt">टाइम लाएँ</button>`;return}
  const N=[['Fajr','फ़ज्र'],['Sunrise','सूरज निकलना'],['Dhuhr','ज़ुहर'],['Asr','अस्र'],['Maghrib','मग़रिब'],['Isha','इशा']],now=new Date(),nm=now.getHours()*60+now.getMinutes();
  const mins=t=>{const [h,m]=t.slice(0,5).split(':');return +h*60+ +m};const nx=N.findIndex(([k])=>mins(p.t[k])>nm);
  el.innerHTML=`<div class="row"><b>🕌 नमाज़ के औक़ात</b><button class="mini" data-a="loadpt">⟳ अपडेट</button></div>`+N.map(([k,h],i)=>`<div class="pt ${i===nx?'nx':''}"><span>${h}</span><b>${p.t[k].slice(0,5)}</b></div>`).join('');
  const hj=$('#hijri');if(hj)hj.textContent=`${p.h.day} ${p.h.month.en} ${p.h.year} हिज्री`}
views.home=()=>{const last=LS.get('last');
  $('#main').innerHTML=`<div class="hero"><div class="ar big">السلام عليكم</div><div>अस्सलामु अलैकुम, <b>${esc(me.name)}</b></div><small id="hijri"></small></div>
  <div class="card" id="prayer"></div>
  ${last?`<div class="item" data-a="open" data-t="${last.t}" data-n="${last.n}"><span class="av">📖</span><div class="fl"><b>तिलावत जारी रखें</b><small class="mu">${({surah:'सूरह',juz:'पारा',page:'पेज'})[last.t]} ${last.n}</small></div></div>`:''}
  <div class="grid">${[['quran','📖','क़ुरान'],['dua','🤲','दुआ'],['tasbih','📿','तस्बीह'],['qibla','🧭','क़िब्ला'],['community','💬','कम्युनिटी'],['profile','👤','प्रोफ़ाइल']].map(([n,i,l])=>`<button class="tile" data-a="nav" data-n="${n}">${i}<span>${l}</span></button>`).join('')}</div>`;renderPrayer()};

/* ---------- quran ---------- */
const API='https://api.alquran.cloud/v1',MAX={surah:114,juz:30,page:604},qcache=new Map();
async function surahs(){let s=LS.get('surahs');if(s)return s;const j=await(await fetch(API+'/surah')).json();s=j.data.map(x=>({n:x.number,a:x.name,e:x.englishName,c:x.numberOfAyahs,t:x.revelationType}));LS.set('surahs',s);return s}
views.quran=async()=>{const tb=LS.get('qtab','s'),m=$('#main'),last=LS.get('last');
  const tabs=`<div class="seg">${[['s','सूरह'],['j','पारा'],['p','पेज']].map(([k,l])=>`<button class="${tb===k?'on':''}" data-a="qtab" data-k="${k}">${l}</button>`).join('')}</div>`;let body='';
  if(tb==='s'){m.innerHTML=tabs+'<p class="mu">लोड हो रहा है…</p>';try{body=(await surahs()).map(x=>`<div class="item" data-a="open" data-t="surah" data-n="${x.n}"><span class="num">${x.n}</span><div class="fl"><b>${x.e}</b><small class="mu">${x.t==='Meccan'?'मक्की':'मदनी'} • ${x.c} आयतें</small></div><span class="ar">${x.a}</span></div>`).join('')}catch{body='<p class="mu">इंटरनेट चेक करें</p>'}}
  else if(tb==='j')body='<div class="gridn">'+Array.from({length:30},(_,i)=>`<button class="tile sm" data-a="open" data-t="juz" data-n="${i+1}">${i+1}<span>पारा</span></button>`).join('')+'</div>';
  else body=`<div class="card"><p>पेज नंबर (1–604)</p><div class="row"><input id="pgn" type="number" min="1" max="604" value="${last?.t==='page'?last.n:1}"><button class="btn" data-a="gopage">खोलें</button></div></div>`;
  if(cur()==='quran')m.innerHTML=tabs+body};
acts.qtab=d=>{LS.set('qtab',d.k);render()};
acts.open=d=>go('reader',{t:d.t,n:+d.n});
acts.gopage=()=>go('reader',{t:'page',n:Math.min(604,Math.max(1,+$('#pgn').value||1))});
views.reader=async({t,n})=>{const m=$('#main');m.innerHTML='<p class="mu">लोड हो रहा है…</p>';$('#title').textContent=({surah:'सूरह',juz:'पारा',page:'पेज'})[t]+' '+n;
  cleanups.push(()=>aud?.pause());
  try{const k=t+n;let d=qcache.get(k);if(!d){const j=await(await fetch(`${API}/${t}/${n}/editions/quran-uthmani,hi.hindi`)).json();d=j.data;qcache.set(k,d)}
    LS.set('last',{t,n});const ar=d[0],hi=d[1],fs=LS.get('qfs',28),tr=LS.get('qtr',true);
    let h=`<div class="tools"><button class="mini" data-a="fs" data-d="-2">A−</button><button class="mini" data-a="fs" data-d="2">A+</button><label><input type="checkbox" style="width:auto" ${tr?'checked':''} data-a="trg"> हिंदी अनुवाद</label></div>`;
    ar.ayahs.forEach((a,i)=>{const s=a.surah||{number:ar.number,name:ar.name,englishName:ar.englishName};let txt=a.text;
      if(a.numberInSurah===1){h+=`<div class="shead"><b>${s.name}</b><small>${s.englishName}</small></div>`;
        if(s.number!==1&&s.number!==9){h+=`<div class="ar bism" style="font-size:${fs}px">بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ</div>`;txt=txt.split(' ').slice(4).join(' ')}}
      h+=`<div class="ay"><div class="ar" style="font-size:${fs}px">${txt} <span class="no">﴿${a.numberInSurah}﴾</span></div>${tr?`<p class="hi">${esc(hi.ayahs[i].text)}</p>`:''}<button class="mini" data-a="play" data-g="${a.number}">▶ सुनें</button></div>`});
    h+=`<div class="row pager"><button class="btn" data-a="pg" data-d="-1" ${n<=1?'disabled':''}>← पिछला</button><button class="btn" data-a="pg" data-d="1" ${n>=MAX[t]?'disabled':''}>अगला →</button></div>`;m.innerHTML=h}
  catch{m.innerHTML='<p class="mu">लोड नहीं हो पाया। इंटरनेट चेक करें।</p>'}};
acts.pg=d=>{stack.at(-1).p.n+=+d.d;render()};
acts.fs=d=>{LS.set('qfs',Math.min(48,Math.max(18,LS.get('qfs',28)+ +d.d)));render()};
acts.trg=(d,b)=>{LS.set('qtr',b.checked);render()};
acts.play=d=>{aud?.pause();aud=new Audio(`https://cdn.islamic.network/quran/audio/128/ar.alafasy/${d.g}.mp3`);aud.play().catch(()=>toast('ऑडियो नहीं चला'))};

/* ---------- dua ---------- */
views.dua=()=>{$('#main').innerHTML=`<input id="dq" placeholder="🔍 दुआ खोजें"><div id="dl"></div>`;
  const draw=q=>{$('#dl').innerHTML=DUAS.map((x,i)=>({x,i})).filter(({x})=>(x.t+x.hi+x.tr).toLowerCase().includes(q.toLowerCase())).map(({x,i})=>`<div class="card dua"><h4>${esc(x.t)}</h4><div class="ar">${x.ar}</div><p class="tr mu">${esc(x.tr)}</p><p>${esc(x.hi)}</p><button class="mini" data-a="copy" data-i="${i}">📋 कॉपी</button></div>`).join('')||'<p class="mu center">कुछ नहीं मिला</p>'};
  draw('');$('#dq').oninput=e=>draw(e.target.value)};
acts.copy=d=>{const x=DUAS[+d.i];navigator.clipboard?.writeText(`${x.t}\n\n${x.ar}\n\n${x.tr}\n\n${x.hi}`);toast('कॉपी हो गया')};

/* ---------- tasbih ---------- */
const ZIKR=[['सुब्हानल्लाह','سُبْحَانَ اللَّهِ'],['अलहम्दुलिल्लाह','الْحَمْدُ لِلَّهِ'],['अल्लाहु अकबर','اللَّهُ أَكْبَرُ'],['ला इलाहा इल्लल्लाह','لَا إِلَٰهَ إِلَّا اللَّهُ'],['अस्तग़फ़िरुल्लाह','أَسْتَغْفِرُ اللَّهَ'],['दरूद शरीफ़','اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ']];
views.tasbih=()=>{const s=LS.get('tz',{i:0,c:0,tg:33,tot:0});
  $('#main').innerHTML=`<div class="card center"><select id="zs" style="width:100%;padding:10px;font-size:16px;border-radius:10px">${ZIKR.map((z,i)=>`<option value="${i}" ${s.i===i?'selected':''}>${z[0]}</option>`).join('')}</select>
  <div class="ar" style="font-size:34px" id="zar">${ZIKR[s.i][1]}</div>
  <button class="tcount" data-a="tap" id="tc">${s.c}</button>
  <div class="row" style="justify-content:center">${[33,99,100,0].map(n=>`<button class="mini" data-a="tg" data-n="${n}" style="${s.tg===n?'background:var(--gold)':''}">${n||'∞'}</button>`).join('')}<button class="mini" data-a="rz">रीसेट</button></div>
  <p class="mu" id="ti">कुल गिनती: ${s.tot}${s.tg?` • लक्ष्य: ${s.tg}`:''}</p></div>`;
  $('#zs').onchange=e=>{const s=LS.get('tz');s.i=+e.target.value;s.c=0;LS.set('tz',s);views.tasbih()}};
acts.tap=()=>{const s=LS.get('tz',{i:0,c:0,tg:33,tot:0});s.c++;s.tot++;LS.set('tz',s);navigator.vibrate?.(15);
  if(s.tg&&s.c>=s.tg){navigator.vibrate?.([80,60,80]);toast('✅ मुकम्मल! माशाअल्लाह');s.c=0;LS.set('tz',s)}$('#tc').textContent=s.c;$('#ti').textContent=`कुल गिनती: ${s.tot}${s.tg?` • लक्ष्य: ${s.tg}`:''}`};
acts.tg=d=>{const s=LS.get('tz',{i:0,c:0,tg:33,tot:0});s.tg=+d.n;s.c=0;LS.set('tz',s);views.tasbih()};
acts.rz=()=>{const s=LS.get('tz',{i:0,c:0,tg:33,tot:0});s.c=0;LS.set('tz',s);views.tasbih()};

/* ---------- qibla ---------- */
const qiblaDeg=(la,lo)=>{const r=Math.PI/180,p1=la*r,p2=21.4225*r,dl=(39.8262-lo)*r;return(Math.atan2(Math.sin(dl)*Math.cos(p2),Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl))/r+360)%360};
views.qibla=()=>{$('#main').innerHTML=`<div class="card center"><div class="compass"><div class="dial" id="dial"><i>N</i></div><div class="needle" id="needle"><span>🕋</span></div></div><h3 id="qdeg">…</h3><p class="mu" id="qst">लोकेशन ली जा रही है…</p></div><p class="mu small">फ़ोन को ज़मीन के बराबर सीधा रखें। सही दिशा के लिए फ़ोन को हवा में "8" की शक्ल में घुमाएँ। 🕋 जब ऊपर ▲ के सामने आ जाए, वही क़िब्ला है।</p>`;
  let bearing=null,heading=0,hit=false;
  const upd=()=>{const d=$('#dial');if(!d)return;d.style.transform=`rotate(${-heading}deg)`;if(bearing==null)return;const r=bearing-heading;$('#needle').style.transform=`rotate(${r}deg)`;
    const ok=Math.abs(((r%360)+540)%360-180)<5;$('#needle').classList.toggle('ok',ok);if(ok&&!hit)navigator.vibrate?.(60);hit=ok};
  getPos().then(({lat,lon})=>{bearing=qiblaDeg(lat,lon);$('#qdeg').textContent=Math.round(bearing)+'° (उत्तर से)';$('#qst').textContent='फ़ोन घुमाएँ जब तक 🕋 ऊपर न आ जाए';upd()}).catch(()=>{$('#qst').textContent='लोकेशन की इजाज़त दें और दोबारा खोलें'});
  const h=e=>{const a=e.webkitCompassHeading!=null?e.webkitCompassHeading:(e.alpha!=null?(360-e.alpha)%360:null);if(a!=null){heading=a;upd()}};
  const ev='ondeviceorientationabsolute'in window?'deviceorientationabsolute':'deviceorientation';addEventListener(ev,h,true);cleanups.push(()=>removeEventListener(ev,h,true))};

/* ---------- profile ---------- */
views.profile=()=>{$('#main').innerHTML=`<div class="card center"><div class="logo">👤</div><h2>${esc(me.name)}</h2><p class="mu">@${esc(me.nick)}<br>${esc(me.email)}</p><p class="small mu">दोस्त आपको ग्रुप/चैट में @${esc(me.nick)} लिखकर जोड़ सकते हैं।</p></div><button class="btn danger" data-a="logout">लॉग आउट</button><p class="mu center small">आयशा कम्युनिटी v1.0</p>`};
acts.logout=async()=>{await signOut(auth)};
